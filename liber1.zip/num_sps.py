import sys
import sqlite3
from PyQt5 import uic
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication, QMainWindow, QRadioButton, QButtonGroup, QDialog


class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('bookmook.ui', self)
        self.pushButton.clicked.connect(self.run)
        self.listWidget.itemDoubleClicked.connect(self.showItem)

    def run(self):
        self.listWidget.clear()
        con = sqlite3.connect(f"bdbooklit.sqlite3")
        cur = con.cursor()
        x1 = self.lineEdit.text()
        x2 = self.comboBox.currentText()
        if x2 == 'Автор':
            self.result = cur.execute(
                f'''SELECT * from allgf where autor like "%{x1}%"''').fetchall()
        elif x2 == 'Название':
            self.result = cur.execute(
                f'''SELECT * from allgf where name like "%{x1}%"''').fetchall()
        lst = [i[1] for i in self.result]
        for i in range(len(lst)):
            curind = self.listWidget.currentRow()
            self.listWidget.insertItem(curind, f'{lst[i]}')

    def showItem(self):
        self.item = self.listWidget.currentRow()
        self.itemmm = self.listWidget.item(self.item)
        x = [i for i in self.result if i[1] == self.itemmm.text()]
        self.w22 = MySecondWidget()
        self.w22.show()
        self.pixmap = QPixmap(f'{x[0][5]}')
        self.w22.namelabel.setText(f'{x[0][1]}')
        self.w22.yearlabel.setText(f'{x[0][3]}')
        self.w22.autolabel.setText(f'{x[0][2]}')
        self.w22.genrelabel.setText(f'{x[0][4]}')
        self.w22.imlabel.setPixmap(self.pixmap)
        self.w22.imlabel.setScaledContents(True)


class MySecondWidget(QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi('dialoge.ui', self)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())
